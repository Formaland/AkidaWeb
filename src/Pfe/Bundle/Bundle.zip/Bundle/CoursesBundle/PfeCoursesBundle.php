<?php

namespace Pfe\Bundle\CoursesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PfeCoursesBundle extends Bundle
{
}
