<?php

namespace Pfe\Bundle\SessionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PfeSessionBundle extends Bundle
{
}
