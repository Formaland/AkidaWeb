<?php

namespace Pfe\Bundle\HoralTestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PfeHoralTestBundle extends Bundle
{
}
