<?php

namespace Pfe\Bundle\ExamenBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PfeExamenBundle extends Bundle
{
}
