<?php

namespace Pfe\Bundle\WebBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PfeWebBundle extends Bundle
{
}
